# ManaDwar Backend -- Phase 1 + 2 Prototype

RFID vehicle-access-control, plus OTP-based visitor entry:

```
Database -> FastAPI -> RFID verification -> Entry logging      (Phase 1)
Database -> FastAPI -> Visitor OTP + temp vehicle credential    (Phase 2)
```

No hardware, no AI yet. This is the part meant to be simulated through Swagger
before a physical RFID reader is connected (Phase 3 -> Phase 4 in the plan).

## ⚠️ If you already ran Phase 1 -- delete your old database first

The visitor feature added new columns and a new table. This prototype creates
tables with `Base.metadata.create_all()`, which only creates tables that don't
exist yet -- it won't add columns to ones you already have. There's no Alembic
migration set up yet (deliberately -- not worth the complexity before the
schema has settled), so the fix for now is just:

```bash
rm manadwar.db          # Windows: del manadwar.db
python -m app.seed
```

## Setup (fresh install)

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env            # defaults to SQLite, no edits needed yet

python -m app.seed              # inserts test residents/vehicles/credentials
uvicorn app.main:app --reload
```

Open **http://127.0.0.1:8000/docs** for interactive Swagger testing.

## Phase 1 test scenarios (RFID) -- match the project's Step 5

| credential_value | Expected result |
|---|---|
| `TEST-RFID-001` | `access: true` -- registered car (Arun Reddy, TS09AB1234) |
| `TEST-RFID-002` | `access: true` -- registered bike (Priya Sharma, TS07XY9876) |
| `UNKNOWN-RFID`  | `access: false` -- "credential not registered" |
| `BLOCKED-RFID`  | `access: false` -- "credential blocked" |

Every attempt -- granted, denied, or unknown -- gets written to `entry_logs`.
Check `GET /entry-logs` for the audit trail, `GET /vehicles` / `GET /credentials`
to see what's seeded.

## Phase 2: visitor entry (OTP)

**Short-term visitor** -- foot/OTP entry only, window is always fixed at 24h,
`vehicle_number` is rejected if provided:

```json
POST /visitors
{
  "name": "Ravi Kumar",
  "phone": "9876543210",
  "host_resident_id": 1,
  "visit_type": "SHORT_TERM",
  "purpose": "Delivery pickup"
}
```

**Long-term visitor** -- must specify `valid_until` (their planned departure),
and can optionally register a vehicle:

```json
POST /visitors
{
  "name": "Sita Rao",
  "phone": "9876500000",
  "host_resident_id": 2,
  "visit_type": "LONG_TERM",
  "purpose": "Staying with family",
  "valid_until": "2026-09-20T12:00:00",
  "vehicle_number": "TS10CD5555"
}
```

The response includes `otp_code` directly (simulating what would otherwise go
out via SMS -- no Twilio/SNS wired up yet, matching the project's own
"simulate first" approach). If a vehicle was registered, its temporary RFID
credential can immediately be tested through the *same* `POST /verify-rfid`
endpoint using `VISITOR-{visitor_id}-{vehicle_number}` as the credential
value -- check `GET /credentials` to see the exact value that was generated.

**Verify the OTP at the gate:**

```json
POST /verify-otp
{
  "otp_code": "048213"
}
```

Granted the first time; denied as "already used" on a second attempt
(single-use, per the SRS's own OTP requirement). Also denied once
`otp_expires_at` has passed. `GET /visitors` shows everything, including OTP
status.

## What's deliberately not here yet

Auth/JWT, Users, Guards, delivery, complaints, notices, and the AI/ANPR
pipeline are all later phases. Real SMS delivery of OTPs (Twilio/AWS SNS) is
also not wired up -- the OTP is returned directly in the API response instead,
which is fine for this simulation stage but would need to change before any
real deployment.

## Moving to PostgreSQL

Nothing in the code is SQLite-specific except the connection string. When
you're ready:

1. `pip install psycopg2-binary` (uncomment it in `requirements.txt`)
2. Set `DATABASE_URL` in `.env` to your Postgres connection string
3. Re-run the app -- tables are created automatically on startup

## What's deliberately not here yet

Auth/JWT, Users, Guards, Complaints, Notices, visitor OTP flow, and the AI/ANPR
pipeline are all later phases. Adding them now would be scope creep on a step
that's meant to prove out one thing: RFID lookup -> decision -> log.

## Known limitation of this delivery

This project was generated in a sandboxed environment with no internet
access, so the FastAPI/SQLAlchemy packages couldn't be installed or the
server actually run here to smoke-test it live. The code was written
carefully and checked for syntax errors, but you should still run it
yourself locally (steps above) as the first thing you do with it.
