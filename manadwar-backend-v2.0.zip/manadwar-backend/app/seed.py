"""
Seed script -- inserts the test data called for in the project's own plan
(Step 3 and Step 5): two registered credentials and one blocked one, so all
three test scenarios (granted / unknown / blocked) are reproducible right
after setup.

Run:
    python -m app.seed
"""
from . import models
from .database import Base, SessionLocal, engine


def seed() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(models.Resident).count() > 0:
            print("Database already has data -- skipping seed.")
            return

        arun = models.Resident(name="Arun Reddy", apartment_no="A-101", phone="9990001111")
        priya = models.Resident(name="Priya Sharma", apartment_no="B-204", phone="9990002222")
        db.add_all([arun, priya])
        db.flush()  # assigns ids without committing yet

        car = models.Vehicle(
            resident_id=arun.id, vehicle_number="TS09AB1234", vehicle_type=models.VehicleType.CAR
        )
        bike = models.Vehicle(
            resident_id=priya.id, vehicle_number="TS07XY9876", vehicle_type=models.VehicleType.BIKE
        )
        db.add_all([car, bike])
        db.flush()

        db.add_all(
            [
                models.VehicleCredential(
                    vehicle_id=car.id,
                    credential_type=models.CredentialType.FASTAG,
                    credential_value="TEST-RFID-001",
                    status=models.CredentialStatus.ACTIVE,
                ),
                models.VehicleCredential(
                    vehicle_id=bike.id,
                    credential_type=models.CredentialType.RFID,
                    credential_value="TEST-RFID-002",
                    status=models.CredentialStatus.ACTIVE,
                ),
                # Old sticker on the car, since revoked -- exercises the
                # "known but blocked" path (BLOCKED-RFID from Step 5).
                models.VehicleCredential(
                    vehicle_id=car.id,
                    credential_type=models.CredentialType.RFID,
                    credential_value="BLOCKED-RFID",
                    status=models.CredentialStatus.BLOCKED,
                ),
            ]
        )
        db.commit()
        print("Seed data inserted: TEST-RFID-001 (active), TEST-RFID-002 (active), BLOCKED-RFID (blocked).")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
