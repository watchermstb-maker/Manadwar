from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..utils import log_attempt

router = APIRouter(tags=["RFID"])


@router.post("/verify-rfid", response_model=schemas.VerifyRFIDResponse)
def verify_rfid(payload: schemas.VerifyRFIDRequest, db: Session = Depends(get_db)):
    credential = (
        db.query(models.VehicleCredential)
        .filter(models.VehicleCredential.credential_value == payload.credential_value)
        .first()
    )

    # Unknown credential -- not in the database at all.
    if credential is None:
        log_attempt(
            db,
            vehicle_id=None,
            credential_id=None,
            visitor_id=None,
            entry_method=models.EntryMethod.RFID,
            credential_value=payload.credential_value,
            gate_name=payload.gate_name,
            direction=payload.direction,
            access=models.AccessResult.DENIED,
        )
        return schemas.VerifyRFIDResponse(
            access=False, message="Access denied: credential not registered"
        )

    # Opportunistic expiry: a temporary (visitor) credential whose window has
    # passed gets flipped to EXPIRED right here, rather than needing a
    # background job to keep credential_status honest.
    if (
        credential.status == models.CredentialStatus.ACTIVE
        and credential.expires_at is not None
        and credential.expires_at < datetime.utcnow()
    ):
        credential.status = models.CredentialStatus.EXPIRED
        db.commit()

    if credential.status != models.CredentialStatus.ACTIVE:
        reason = "expired" if credential.status == models.CredentialStatus.EXPIRED else "blocked"
        log_attempt(
            db,
            vehicle_id=credential.vehicle_id,
            credential_id=credential.id,
            visitor_id=credential.visitor_id,
            entry_method=models.EntryMethod.RFID,
            credential_value=payload.credential_value,
            gate_name=payload.gate_name,
            direction=payload.direction,
            access=models.AccessResult.DENIED,
        )
        return schemas.VerifyRFIDResponse(
            access=False, message=f"Access denied: credential {reason}"
        )

    # Known, active, unexpired credential -- grant access.
    vehicle = credential.vehicle
    log_attempt(
        db,
        vehicle_id=vehicle.id,
        credential_id=credential.id,
        visitor_id=credential.visitor_id,
        entry_method=models.EntryMethod.RFID,
        credential_value=payload.credential_value,
        gate_name=payload.gate_name,
        direction=payload.direction,
        access=models.AccessResult.GRANTED,
    )
    return schemas.VerifyRFIDResponse(
        access=True,
        message="Access granted",
        vehicle_number=vehicle.vehicle_number,
        vehicle_type=vehicle.vehicle_type,
    )


@router.get("/entry-logs", response_model=List[schemas.EntryLogOut])
def list_entry_logs(db: Session = Depends(get_db)):
    """Audit trail -- includes denied/unmatched attempts, most recent first."""
    return db.query(models.EntryLog).order_by(models.EntryLog.timestamp.desc()).all()


@router.get("/vehicles", response_model=List[schemas.VehicleOut])
def list_vehicles(db: Session = Depends(get_db)):
    return db.query(models.Vehicle).all()


@router.get("/credentials", response_model=List[schemas.CredentialOut])
def list_credentials(db: Session = Depends(get_db)):
    return db.query(models.VehicleCredential).all()
