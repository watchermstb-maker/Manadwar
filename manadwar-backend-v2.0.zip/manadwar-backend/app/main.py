"""
ManaDwar - Access Control API

    app/routers/rfid.py      -> vehicle RFID verification + logs (Phase 1)
    app/routers/visitors.py  -> OTP-based visitor entry (Phase 2)

Run locally:
    uvicorn app.main:app --reload

Then open http://127.0.0.1:8000/docs to simulate scans and visitor flows via
Swagger, before any physical reader is connected.
"""
from fastapi import FastAPI

from .database import Base, engine
from .routers import rfid, visitors

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="ManaDwar - Access Control API",
    description="RFID vehicle access control plus OTP-based visitor entry.",
    version="2.0.0",
)

app.include_router(rfid.router)
app.include_router(visitors.router)
