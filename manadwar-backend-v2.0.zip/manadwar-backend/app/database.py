"""
Database engine + session setup.

Defaults to SQLite (zero-setup, matches the SRS's own recommendation for the
prototype stage). To move to PostgreSQL later, just set DATABASE_URL, e.g.:

    DATABASE_URL=postgresql://user:password@localhost:5432/manadwar

Nothing else in the codebase needs to change — SQLAlchemy handles the dialect
switch, as long as psycopg2-binary is installed for the Postgres case.
"""
import os

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./manadwar.db")

# SQLite needs this flag when used with FastAPI's threaded request handling.
# Postgres (or any other dialect) doesn't need it.
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI dependency that yields a DB session and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
