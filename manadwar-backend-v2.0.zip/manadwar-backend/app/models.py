"""
Core models.

    Resident -> Vehicle -> VehicleCredential -> EntryLog   (Phase 1: RFID)
    Resident -> Visitor -> (OTP | temp VehicleCredential)  (Phase 2: visitors)

Design notes:
- VehicleCredential is generic (credential_type: FASTAG | RFID) and now also
  scoped (credential_scope: RESIDENT | VISITOR) with an optional expires_at.
  A resident's credential has expires_at = NULL (permanent). A long-term
  visitor's vehicle gets a credential with expires_at set to their departure
  date, so it flows through the exact same /verify-rfid check as everyone
  else -- no separate "visitor verification" code path needed for vehicles.
- Vehicle.resident_id is nullable because a visitor's vehicle isn't owned by
  any resident; it's linked back to whoever it belongs to via the
  credential's visitor_id instead.
- EntryLog keeps a copy of whatever was presented at the gate (RFID value or
  OTP code) plus an entry_method flag, so the audit trail reads clearly even
  for denied/unmatched attempts that have no resolvable vehicle or visitor.
"""
import enum
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime
from sqlalchemy import Enum as SAEnum
from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from .database import Base


class VehicleType(str, enum.Enum):
    CAR = "CAR"
    BIKE = "BIKE"


class CredentialType(str, enum.Enum):
    FASTAG = "FASTAG"
    RFID = "RFID"


class CredentialStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    BLOCKED = "BLOCKED"
    EXPIRED = "EXPIRED"


class CredentialScope(str, enum.Enum):
    RESIDENT = "RESIDENT"
    VISITOR = "VISITOR"


class VisitType(str, enum.Enum):
    SHORT_TERM = "SHORT_TERM"
    LONG_TERM = "LONG_TERM"


class EntryMethod(str, enum.Enum):
    RFID = "RFID"
    OTP = "OTP"


class Direction(str, enum.Enum):
    IN = "IN"
    OUT = "OUT"


class AccessResult(str, enum.Enum):
    GRANTED = "GRANTED"
    DENIED = "DENIED"


class Resident(Base):
    __tablename__ = "residents"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    apartment_no = Column(String, nullable=False)
    phone = Column(String, nullable=True)

    vehicles = relationship("Vehicle", back_populates="resident")


class Vehicle(Base):
    __tablename__ = "vehicles"

    id = Column(Integer, primary_key=True, index=True)
    resident_id = Column(Integer, ForeignKey("residents.id"), nullable=True)
    vehicle_number = Column(String, nullable=False, unique=True)
    vehicle_type = Column(SAEnum(VehicleType), nullable=False)

    resident = relationship("Resident", back_populates="vehicles")
    credentials = relationship("VehicleCredential", back_populates="vehicle")


class Visitor(Base):
    __tablename__ = "visitors"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    host_resident_id = Column(Integer, ForeignKey("residents.id"), nullable=False)
    visit_type = Column(SAEnum(VisitType), nullable=False)
    purpose = Column(String, nullable=True)

    valid_from = Column(DateTime, default=datetime.utcnow)
    valid_until = Column(DateTime, nullable=False)

    # Only set for LONG_TERM visitors who register a vehicle.
    vehicle_number = Column(String, nullable=True)

    otp_code = Column(String, nullable=False)
    otp_expires_at = Column(DateTime, nullable=False)
    otp_verified = Column(Boolean, nullable=False, default=False)
    otp_verified_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    host_resident = relationship("Resident")
    vehicle_credential = relationship(
        "VehicleCredential", back_populates="visitor", uselist=False
    )


class VehicleCredential(Base):
    __tablename__ = "vehicle_credentials"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=False)
    credential_type = Column(SAEnum(CredentialType), nullable=False)
    credential_value = Column(String, nullable=False, unique=True, index=True)
    status = Column(SAEnum(CredentialStatus), nullable=False, default=CredentialStatus.ACTIVE)
    credential_scope = Column(SAEnum(CredentialScope), nullable=False, default=CredentialScope.RESIDENT)
    expires_at = Column(DateTime, nullable=True)  # NULL = permanent (resident credentials)
    visitor_id = Column(Integer, ForeignKey("visitors.id"), nullable=True)
    issued_date = Column(DateTime, default=datetime.utcnow)

    vehicle = relationship("Vehicle", back_populates="credentials")
    visitor = relationship("Visitor", back_populates="vehicle_credential")


class EntryLog(Base):
    __tablename__ = "entry_logs"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=True)
    credential_id = Column(Integer, ForeignKey("vehicle_credentials.id"), nullable=True)
    visitor_id = Column(Integer, ForeignKey("visitors.id"), nullable=True)
    entry_method = Column(SAEnum(EntryMethod), nullable=False, default=EntryMethod.RFID)
    credential_value = Column(String, nullable=False)  # RFID value OR OTP code presented at the gate
    gate_name = Column(String, nullable=False, default="MAIN_GATE")
    direction = Column(SAEnum(Direction), nullable=False, default=Direction.IN)
    access = Column(SAEnum(AccessResult), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
