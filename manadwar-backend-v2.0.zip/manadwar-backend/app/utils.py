import random
from typing import Optional

from sqlalchemy.orm import Session

from . import models


def generate_otp(length: int = 6) -> str:
    """
    Numeric OTP, e.g. '048213'.

    Not enforced unique at the DB level -- lookups filter on otp_verified and
    expiry, so a coincidental repeat across different visitors isn't
    exploitable in practice at prototype volume. Worth revisiting (e.g. a
    uniqueness retry loop) before any real deployment.
    """
    return "".join(str(random.randint(0, 9)) for _ in range(length))


def log_attempt(
    db: Session,
    *,
    vehicle_id: Optional[int],
    credential_id: Optional[int],
    visitor_id: Optional[int],
    entry_method: models.EntryMethod,
    credential_value: str,
    gate_name: str,
    direction: models.Direction,
    access: models.AccessResult,
) -> None:
    """Writes one row to entry_logs. Shared by the RFID and OTP verification
    paths so every gate event -- granted, denied, or unmatched -- lands in
    the same audit trail."""
    db.add(
        models.EntryLog(
            vehicle_id=vehicle_id,
            credential_id=credential_id,
            visitor_id=visitor_id,
            entry_method=entry_method,
            credential_value=credential_value,
            gate_name=gate_name,
            direction=direction,
            access=access,
        )
    )
    db.commit()
