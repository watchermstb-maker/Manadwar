# ManaDwar Backend -- Phase 1 + 2 + 3 + 4

RFID vehicle access control, OTP-based visitor entry, delivery approval, and
maintenance billing/complaints, with a demo gate-terminal UI at
http://127.0.0.1:8000/ (Swagger still at /docs).

## Setup

    python3 -m venv venv
    source venv/bin/activate        # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    cp .env.example .env
    python -m app.seed
    uvicorn app.main:app --reload

Open http://127.0.0.1:8000/ for the demo UI, or /docs for Swagger testing.

## Phase 3: delivery approval

**Auto-approval** (simulates the platform having already verified the
courier/order -- approved and logged instantly):

    POST /deliveries
    {
      "courier_name": "Ramesh (Amazon)",
      "platform": "Amazon",
      "host_resident_id": 1,
      "purpose": "Order #4471",
      "approval_mode": "AUTO"
    }

Response comes back with `"status": "APPROVED"` right away.

**Manual approval** -- stays `PENDING` until the resident decides:

    POST /deliveries
    {
      "courier_name": "Suresh (local grocery)",
      "host_resident_id": 2,
      "approval_mode": "MANUAL"
    }

Then, as the resident:

    POST /deliveries/{id}/decision
    { "approve": true }

That decision call is the moment access is actually granted or denied --
check `GET /entry-logs` afterward and you'll see it logged with
`entry_method: "DELIVERY"`, but only from the decision step, not the
creation step (nothing is granted/denied until someone actually decides).

`GET /deliveries` lists everything, so a guard can poll to see when a
pending one flips to approved.

## Phase 4: maintenance bills + complaints

**Create a bill** for a resident:

    POST /maintenance/bills
    {
      "resident_id": 1,
      "billing_month": "2026-09",
      "amount_due": 3500,
      "due_date": "2026-09-10T00:00:00"
    }

**Mark it paid:**

    POST /maintenance/bills/{id}/pay
    { "payment_reference": "UPI-REF-1234" }

Check `GET /maintenance/bills` -- a bill created with a `due_date` already
in the past and never paid will show up as `OVERDUE`, not `PENDING`. That
flip happens the moment the list is read (same opportunistic-status pattern
used for expired visitor credentials), not on a schedule -- so it only
updates when someone actually asks. Filter with `?resident_id=1` if needed.

**Raise a complaint:**

    POST /complaints
    {
      "resident_id": 1,
      "category": "Plumbing",
      "description": "Leaking pipe in the parking basement"
    }

**Update its status** (as staff/admin):

    POST /complaints/{id}/status
    { "status": "IN_PROGRESS" }

    POST /complaints/{id}/status
    { "status": "RESOLVED", "resolution_notes": "Pipe replaced 12 Sept" }

`GET /complaints` lists everything; filter with `?resident_id=1` or
`?status=OPEN`.

Note: there's no payment gateway here -- `payment_reference` is just a
free-text field the caller supplies, standing in for whatever a real UPI/
card transaction would confirm. Same simplification as the OTP-via-SMS and
delivery auto-approval stand-ins elsewhere in this project.
