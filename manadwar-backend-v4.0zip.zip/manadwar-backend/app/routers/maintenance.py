from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db

router = APIRouter(tags=["Maintenance"])


def _validate_billing_month(value: str) -> None:
    try:
        datetime.strptime(value, "%Y-%m")
    except ValueError:
        raise HTTPException(status_code=400, detail="billing_month must be in YYYY-MM format, e.g. '2026-09'")


# ---- Bills ----

@router.post("/maintenance/bills", response_model=schemas.MaintenanceBillOut)
def create_bill(payload: schemas.MaintenanceBillCreate, db: Session = Depends(get_db)):
    resident = db.query(models.Resident).filter(models.Resident.id == payload.resident_id).first()
    if resident is None:
        raise HTTPException(status_code=404, detail="resident_id does not match any resident")

    _validate_billing_month(payload.billing_month)

    bill = models.MaintenanceBill(
        resident_id=payload.resident_id,
        billing_month=payload.billing_month,
        amount_due=payload.amount_due,
        due_date=payload.due_date,
    )
    db.add(bill)
    db.commit()
    db.refresh(bill)
    return bill


@router.post("/maintenance/bills/{bill_id}/pay", response_model=schemas.MaintenanceBillOut)
def pay_bill(bill_id: int, payload: schemas.MaintenanceBillPay, db: Session = Depends(get_db)):
    bill = db.query(models.MaintenanceBill).filter(models.MaintenanceBill.id == bill_id).first()
    if bill is None:
        raise HTTPException(status_code=404, detail="No bill with that id")

    if bill.status == models.BillStatus.PAID:
        raise HTTPException(status_code=400, detail="This bill is already paid")

    bill.status = models.BillStatus.PAID
    bill.paid_at = datetime.utcnow()
    bill.payment_reference = payload.payment_reference

    db.commit()
    db.refresh(bill)
    return bill


@router.get("/maintenance/bills", response_model=List[schemas.MaintenanceBillOut])
def list_bills(resident_id: Optional[int] = Query(None), db: Session = Depends(get_db)):
    now = datetime.utcnow()

    # Opportunistic overdue flip -- same pattern as expiring visitor
    # credentials: no background job, status is corrected the moment it's
    # actually read rather than needing a scheduler to sweep for it.
    stale = db.query(models.MaintenanceBill).filter(
        models.MaintenanceBill.status == models.BillStatus.PENDING,
        models.MaintenanceBill.due_date < now,
    ).all()
    for bill in stale:
        bill.status = models.BillStatus.OVERDUE
    if stale:
        db.commit()

    query = db.query(models.MaintenanceBill)
    if resident_id is not None:
        query = query.filter(models.MaintenanceBill.resident_id == resident_id)
    return query.order_by(models.MaintenanceBill.due_date.desc()).all()


# ---- Complaints ----

@router.post("/complaints", response_model=schemas.ComplaintOut)
def create_complaint(payload: schemas.ComplaintCreate, db: Session = Depends(get_db)):
    resident = db.query(models.Resident).filter(models.Resident.id == payload.resident_id).first()
    if resident is None:
        raise HTTPException(status_code=404, detail="resident_id does not match any resident")

    complaint = models.Complaint(
        resident_id=payload.resident_id,
        category=payload.category,
        description=payload.description,
    )
    db.add(complaint)
    db.commit()
    db.refresh(complaint)
    return complaint


@router.post("/complaints/{complaint_id}/status", response_model=schemas.ComplaintOut)
def update_complaint_status(complaint_id: int, payload: schemas.ComplaintStatusUpdate, db: Session = Depends(get_db)):
    complaint = db.query(models.Complaint).filter(models.Complaint.id == complaint_id).first()
    if complaint is None:
        raise HTTPException(status_code=404, detail="No complaint with that id")

    complaint.status = payload.status
    if payload.resolution_notes is not None:
        complaint.resolution_notes = payload.resolution_notes
    if payload.status == models.ComplaintStatus.RESOLVED:
        complaint.resolved_at = datetime.utcnow()

    db.commit()
    db.refresh(complaint)
    return complaint


@router.get("/complaints", response_model=List[schemas.ComplaintOut])
def list_complaints(
    resident_id: Optional[int] = Query(None),
    status: Optional[models.ComplaintStatus] = Query(None),
    db: Session = Depends(get_db),
):
    query = db.query(models.Complaint)
    if resident_id is not None:
        query = query.filter(models.Complaint.resident_id == resident_id)
    if status is not None:
        query = query.filter(models.Complaint.status == status)
    return query.order_by(models.Complaint.raised_at.desc()).all()
