import random
from typing import Optional

from sqlalchemy.orm import Session

from . import models


def generate_otp(length: int = 6) -> str:
    return "".join(str(random.randint(0, 9)) for _ in range(length))


def log_attempt(
    db: Session,
    *,
    vehicle_id: Optional[int],
    credential_id: Optional[int],
    visitor_id: Optional[int],
    entry_method: models.EntryMethod,
    credential_value: str,
    gate_name: str,
    direction: models.Direction,
    access: models.AccessResult,
    delivery_id: Optional[int] = None,
) -> None:
    db.add(models.EntryLog(
        vehicle_id=vehicle_id, credential_id=credential_id, visitor_id=visitor_id,
        delivery_id=delivery_id, entry_method=entry_method, credential_value=credential_value,
        gate_name=gate_name, direction=direction, access=access,
    ))
    db.commit()
