from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict

from .models import (
    AccessResult,
    ApprovalMode,
    CredentialType,
    DeliveryStatus,
    Direction,
    EntryMethod,
    VehicleType,
    VisitType,
)


class VerifyRFIDRequest(BaseModel):
    credential_value: str
    gate_name: str = "MAIN_GATE"
    direction: Direction = Direction.IN


class VerifyRFIDResponse(BaseModel):
    access: bool
    message: str
    vehicle_number: Optional[str] = None
    vehicle_type: Optional[VehicleType] = None


class VehicleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    vehicle_number: str
    vehicle_type: VehicleType
    resident_id: Optional[int]


class CredentialOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    vehicle_id: int
    credential_type: CredentialType
    credential_value: str
    status: str
    credential_scope: str
    expires_at: Optional[datetime]


class EntryLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    vehicle_id: Optional[int]
    visitor_id: Optional[int]
    delivery_id: Optional[int]
    entry_method: EntryMethod
    credential_value: str
    gate_name: str
    direction: Direction
    access: AccessResult
    timestamp: datetime


class ResidentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    apartment_no: str
    phone: Optional[str]


class VisitorCreate(BaseModel):
    name: str
    phone: str
    host_resident_id: int
    visit_type: VisitType
    purpose: Optional[str] = None
    valid_until: Optional[datetime] = None
    vehicle_number: Optional[str] = None


class VisitorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    phone: str
    host_resident_id: int
    visit_type: VisitType
    purpose: Optional[str]
    valid_from: datetime
    valid_until: datetime
    vehicle_number: Optional[str]
    otp_code: str
    otp_expires_at: datetime
    otp_verified: bool
    created_at: datetime


class VerifyOTPRequest(BaseModel):
    otp_code: str
    gate_name: str = "MAIN_GATE"
    direction: Direction = Direction.IN


class VerifyOTPResponse(BaseModel):
    access: bool
    message: str
    visitor_name: Optional[str] = None


# ---- Deliveries ----

class DeliveryCreate(BaseModel):
    courier_name: str
    courier_phone: Optional[str] = None
    host_resident_id: int
    platform: Optional[str] = None  # e.g. "Amazon", "Swiggy", "Local"
    purpose: Optional[str] = None
    approval_mode: ApprovalMode


class DeliveryDecision(BaseModel):
    approve: bool
    gate_name: str = "MAIN_GATE"
    direction: Direction = Direction.IN


class DeliveryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    courier_name: str
    courier_phone: Optional[str]
    platform: Optional[str]
    host_resident_id: int
    purpose: Optional[str]
    approval_mode: ApprovalMode
    status: DeliveryStatus
    requested_at: datetime
    decided_at: Optional[datetime]
