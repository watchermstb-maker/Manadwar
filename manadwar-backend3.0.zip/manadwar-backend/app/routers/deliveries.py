from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..utils import log_attempt

router = APIRouter(tags=["Deliveries"])


@router.post("/deliveries", response_model=schemas.DeliveryOut)
def create_delivery(payload: schemas.DeliveryCreate, db: Session = Depends(get_db)):
    """
    Creating a delivery request represents the courier arriving at the gate.

    - AUTO: simulates inter-app verification (e.g. the platform already
      confirmed the order and courier) -- approved immediately, and access is
      granted and logged in the same step.
    - MANUAL: stays PENDING until the resident calls the decision endpoint
      below; nothing is logged yet, since nothing has been decided.
    """
    host = db.query(models.Resident).filter(models.Resident.id == payload.host_resident_id).first()
    if host is None:
        raise HTTPException(status_code=404, detail="host_resident_id does not match any resident")

    now = datetime.utcnow()
    delivery = models.Delivery(
        courier_name=payload.courier_name,
        courier_phone=payload.courier_phone,
        platform=payload.platform,
        host_resident_id=payload.host_resident_id,
        purpose=payload.purpose,
        approval_mode=payload.approval_mode,
        status=models.DeliveryStatus.PENDING,
    )

    if payload.approval_mode == models.ApprovalMode.AUTO:
        delivery.status = models.DeliveryStatus.APPROVED
        delivery.decided_at = now

    db.add(delivery)
    db.flush()  # assigns delivery.id before we log against it

    if payload.approval_mode == models.ApprovalMode.AUTO:
        log_attempt(
            db,
            vehicle_id=None,
            credential_id=None,
            visitor_id=None,
            delivery_id=delivery.id,
            entry_method=models.EntryMethod.DELIVERY,
            credential_value=delivery.courier_name,
            gate_name="MAIN_GATE",
            direction=models.Direction.IN,
            access=models.AccessResult.GRANTED,
        )

    db.commit()
    db.refresh(delivery)
    return delivery


@router.post("/deliveries/{delivery_id}/decision", response_model=schemas.DeliveryOut)
def decide_delivery(delivery_id: int, payload: schemas.DeliveryDecision, db: Session = Depends(get_db)):
    """Resident's approve/deny call for a MANUAL delivery. This is the moment
    access is actually granted or denied -- logged here, not at creation."""
    delivery = db.query(models.Delivery).filter(models.Delivery.id == delivery_id).first()
    if delivery is None:
        raise HTTPException(status_code=404, detail="No delivery request with that id")

    if delivery.approval_mode != models.ApprovalMode.MANUAL:
        raise HTTPException(status_code=400, detail="Only manual-approval deliveries take a decision")

    if delivery.status != models.DeliveryStatus.PENDING:
        raise HTTPException(status_code=400, detail=f"This delivery was already {delivery.status.value.lower()}")

    delivery.status = models.DeliveryStatus.APPROVED if payload.approve else models.DeliveryStatus.DENIED
    delivery.decided_at = datetime.utcnow()

    log_attempt(
        db,
        vehicle_id=None,
        credential_id=None,
        visitor_id=None,
        delivery_id=delivery.id,
        entry_method=models.EntryMethod.DELIVERY,
        credential_value=delivery.courier_name,
        gate_name=payload.gate_name,
        direction=payload.direction,
        access=models.AccessResult.GRANTED if payload.approve else models.AccessResult.DENIED,
    )

    db.commit()
    db.refresh(delivery)
    return delivery


@router.get("/deliveries", response_model=List[schemas.DeliveryOut])
def list_deliveries(db: Session = Depends(get_db)):
    return db.query(models.Delivery).order_by(models.Delivery.requested_at.desc()).all()
