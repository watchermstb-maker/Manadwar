from datetime import datetime, timedelta
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..utils import generate_otp, log_attempt

router = APIRouter(tags=["Visitors"])

SHORT_TERM_WINDOW = timedelta(hours=24)
OTP_VALIDITY_WINDOW = timedelta(hours=24)


@router.post("/visitors", response_model=schemas.VisitorOut)
def create_visitor(payload: schemas.VisitorCreate, db: Session = Depends(get_db)):
    host = db.query(models.Resident).filter(models.Resident.id == payload.host_resident_id).first()
    if host is None:
        raise HTTPException(status_code=404, detail="host_resident_id does not match any resident")

    now = datetime.utcnow()

    if payload.visit_type == models.VisitType.SHORT_TERM:
        if payload.vehicle_number:
            raise HTTPException(status_code=400, detail=(
                "Short-term visitors are foot/OTP entry only -- vehicle "
                "credentials are only issued for long-term visitors."))
        valid_until = now + SHORT_TERM_WINDOW
    else:
        if payload.valid_until is None:
            raise HTTPException(status_code=400,
                                 detail="valid_until (planned departure date) is required for long-term visitors")
        if payload.valid_until <= now:
            raise HTTPException(status_code=400, detail="valid_until must be in the future")
        valid_until = payload.valid_until

    visitor = models.Visitor(
        name=payload.name, phone=payload.phone, host_resident_id=payload.host_resident_id,
        visit_type=payload.visit_type, purpose=payload.purpose, valid_from=now, valid_until=valid_until,
        vehicle_number=payload.vehicle_number, otp_code=generate_otp(),
        otp_expires_at=min(valid_until, now + OTP_VALIDITY_WINDOW),
    )
    db.add(visitor)
    db.flush()

    if payload.visit_type == models.VisitType.LONG_TERM and payload.vehicle_number:
        vehicle = db.query(models.Vehicle).filter(
            models.Vehicle.vehicle_number == payload.vehicle_number
        ).first()
        if vehicle is None:
            vehicle = models.Vehicle(resident_id=None, vehicle_number=payload.vehicle_number,
                                      vehicle_type=models.VehicleType.CAR)
            db.add(vehicle)
            db.flush()

        db.add(models.VehicleCredential(
            vehicle_id=vehicle.id, credential_type=models.CredentialType.RFID,
            credential_value=f"VISITOR-{visitor.id}-{payload.vehicle_number}",
            status=models.CredentialStatus.ACTIVE, credential_scope=models.CredentialScope.VISITOR,
            expires_at=valid_until, visitor_id=visitor.id,
        ))

    db.commit()
    db.refresh(visitor)
    return visitor


@router.post("/verify-otp", response_model=schemas.VerifyOTPResponse)
def verify_otp(payload: schemas.VerifyOTPRequest, db: Session = Depends(get_db)):
    visitor = db.query(models.Visitor).filter(
        models.Visitor.otp_code == payload.otp_code,
        models.Visitor.otp_verified.is_(False),
    ).order_by(models.Visitor.created_at.desc()).first()

    if visitor is None:
        log_attempt(db, vehicle_id=None, credential_id=None, visitor_id=None,
                    entry_method=models.EntryMethod.OTP, credential_value=payload.otp_code,
                    gate_name=payload.gate_name, direction=payload.direction, access=models.AccessResult.DENIED)
        return schemas.VerifyOTPResponse(access=False, message="Access denied: OTP invalid or already used")

    if visitor.otp_expires_at < datetime.utcnow():
        log_attempt(db, vehicle_id=None, credential_id=None, visitor_id=visitor.id,
                    entry_method=models.EntryMethod.OTP, credential_value=payload.otp_code,
                    gate_name=payload.gate_name, direction=payload.direction, access=models.AccessResult.DENIED)
        return schemas.VerifyOTPResponse(access=False, message="Access denied: OTP expired")

    visitor.otp_verified = True
    visitor.otp_verified_at = datetime.utcnow()
    db.commit()

    log_attempt(db, vehicle_id=None, credential_id=None, visitor_id=visitor.id,
                entry_method=models.EntryMethod.OTP, credential_value=payload.otp_code,
                gate_name=payload.gate_name, direction=payload.direction, access=models.AccessResult.GRANTED)
    return schemas.VerifyOTPResponse(access=True, message="Access granted", visitor_name=visitor.name)


@router.get("/visitors", response_model=List[schemas.VisitorOut])
def list_visitors(db: Session = Depends(get_db)):
    return db.query(models.Visitor).order_by(models.Visitor.created_at.desc()).all()
