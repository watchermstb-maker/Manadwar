"""
ManaDwar - Access Control API

    app/routers/rfid.py      -> vehicle RFID verification + logs (Phase 1)
    app/routers/visitors.py  -> OTP-based visitor entry (Phase 2)
    app/static/index.html    -> demo gate-terminal UI (for showing the team)

Run locally:
    uvicorn app.main:app --reload

Then open http://127.0.0.1:8000/ for the demo UI, or
http://127.0.0.1:8000/docs for raw Swagger testing.
"""
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from .database import Base, engine
from .routers import deliveries, rfid, visitors

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="ManaDwar - Access Control API",
    description="RFID vehicle access control, OTP-based visitor entry, and delivery approval.",
    version="3.0.0",
)

app.include_router(rfid.router)
app.include_router(visitors.router)
app.include_router(deliveries.router)

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/app", StaticFiles(directory=STATIC_DIR, html=True), name="frontend")


@app.get("/", include_in_schema=False)
def root():
    """Convenience redirect so the bare server URL opens the demo UI directly."""
    return RedirectResponse(url="/app/")
