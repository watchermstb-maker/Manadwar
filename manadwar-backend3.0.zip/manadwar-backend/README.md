# ManaDwar Backend -- Phase 1 + 2 + 3

RFID vehicle access control, OTP-based visitor entry, and delivery approval,
with a demo gate-terminal UI at http://127.0.0.1:8000/ (Swagger still at /docs).

## Setup

    python3 -m venv venv
    source venv/bin/activate        # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    cp .env.example .env
    python -m app.seed
    uvicorn app.main:app --reload

Open http://127.0.0.1:8000/ for the demo UI, or /docs for Swagger testing.

## Phase 3: delivery approval

**Auto-approval** (simulates the platform having already verified the
courier/order -- approved and logged instantly):

    POST /deliveries
    {
      "courier_name": "Ramesh (Amazon)",
      "platform": "Amazon",
      "host_resident_id": 1,
      "purpose": "Order #4471",
      "approval_mode": "AUTO"
    }

Response comes back with `"status": "APPROVED"` right away.

**Manual approval** -- stays `PENDING` until the resident decides:

    POST /deliveries
    {
      "courier_name": "Suresh (local grocery)",
      "host_resident_id": 2,
      "approval_mode": "MANUAL"
    }

Then, as the resident:

    POST /deliveries/{id}/decision
    { "approve": true }

That decision call is the moment access is actually granted or denied --
check `GET /entry-logs` afterward and you'll see it logged with
`entry_method: "DELIVERY"`, but only from the decision step, not the
creation step (nothing is granted/denied until someone actually decides).

`GET /deliveries` lists everything, so a guard can poll to see when a
pending one flips to approved.
